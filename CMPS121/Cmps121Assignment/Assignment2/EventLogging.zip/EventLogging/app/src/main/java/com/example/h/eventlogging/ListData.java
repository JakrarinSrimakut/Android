package com.example.h.eventlogging;

import android.os.Parcelable;

import java.io.Serializable;

public class ListData implements Serializable{
    public String titleText;
    public String gpsText;
    public String timeText;
    public String dateText;
    public String eventText;
}
